import main


main.main()
